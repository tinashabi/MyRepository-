var mition = [];
var plus = document.getElementById("col");
var i = 0;



function drawHtml() {
   
    var combineHtml = '';
    mition.map(function (obj) {
        combineHtml = combineHtml + obj.html;
    })
    plus.innerHTML = combineHtml;  
};


    var p = plus.innerHTML;
function add() {
    var myInput = document.getElementById("m");
    var dString = myInput.value;

    var mt = document.getElementById("t");
    var con = mt.value;

    var mysave = document.getElementById("s")
    var myNumber = mysave.value;

    // add new note to mition

    var newd = {
        id: i,
        text: dString,
        date: myNumber,
        time: con,
        html: '',
        
        
    };
    if( dString==""){
        alert("Opes!");
    
    }
    else{ 
    
    newd.html =
        `<div class="col-sm-6 col-md-6 col-lg-6 col-xl-6 note "> 
                        <h2>To Do...</h2>
                        <textarea readonly>${newd.text} </textarea>
                        <h3>${newd.date} </h3>
                        <h4>${newd.time} </h4>
                        <button class="btn"  onclick="remove(${newd.id})" ><i class="fa fa-close"></i></button>
                    </div>`;
                
                
    mition.push(newd);
    i = Date.now();
    drawHtml();
    saveToLocalStorage();   
}
}


function loadPrevItems()
{
   var allSavedRes= localStorage.getItem("allRes");
    if(allSavedRes)
    {
        mition= JSON.parse(allSavedRes);
        drawHtml(); 
    }  
}
function draw() {
    $("#col").empty();
    var htmlToAdd="";

    for (let i = 0; i < mition.length; i++) {
        htmlToAdd+=
            `
    <div class="col-sm-6 col-md-6 col-lg-6 col-xl-6">
        <h1>${mition[i].time}</h1>
        <h2>${mition[i].date}</h2>
        <h5>${mition[i].text}</h5>
    </div>
    `;
        $("#col").html(htmlToAdd);
    }  
}
function saveToLocalStorage()
{
    var allResAsString= JSON.stringify(mition);
    localStorage.setItem("allRes",allResAsString );
}
function remove(id) {
    mition = mition.filter(function (obj) {
        return obj.id !== id;
    });
 
    var allResAsString= JSON.stringify(mition);
    localStorage.setItem("allRes",allResAsString );
    drawHtml();
}
function ci() {
    let allResAsString= JSON.stringify(mition);
    localStorage.clear("allRes",allResAsString );
    plus.innerHTML = "";
    i = 0;
    
    
}




