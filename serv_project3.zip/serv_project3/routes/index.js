var express = require('express');
var router = express.Router();
var mysql = require('promise-mysql');

var pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: 'root',
    connectionLimit: 10
});


router.get('/createDB', async function (req, res, next) { 
  try {
      await pool.query("CREATE DATABASE project");
      //here we already have db lets create table
      var creatTableQuery1 = `
      CREATE TABLE project.users (
      userid INT NOT NULL AUTO_INCREMENT,
      name VARCHAR(45) NULL,
      lastname VARCHAR(45) NULL,
      username VARCHAR(45) NULL,
      password VARCHAR(45) NULL,
      PRIMARY KEY (userid))  `;
      await pool.query(creatTableQuery1);

      var creatTableQuery2 = `
      CREATE TABLE project.vacation (
      id INT NOT NULL AUTO_INCREMENT,
      description VARCHAR(45) NULL,
      destination VARCHAR(45) NULL,
      image VARCHAR(100) NULL,
      start VARCHAR(45) NULL,
      end VARCHAR(45) NULL,
      price VARCHAR(45) NULL,
      PRIMARY KEY (id))  `;
      await pool.query(creatTableQuery2);

      var creatTableQuery3 = `
      CREATE TABLE project.follow (
      id INT NOT NULL AUTO_INCREMENT,
      userid VARCHAR(45) NULL,
      follow VARCHAR(45) NULL,
      PRIMARY KEY (id))  `;
      await pool.query(creatTableQuery3);

      res.send("DB and 3 table created");
  } catch (err) {
      console.log(err);
  } 
});

//register users

router.post('/register', async function (req, res, next) {  
  let insertQuery4=`
  INSERT INTO project.users (name , lastname , username , password) 
  VALUES ('${req.body.name}','${req.body.lastname}' , '${req.body.username2}' , '${req.body.password2}')
  `;
  var result = await pool.query(insertQuery4); 
  res.json(result);
  alert("registed!")
}); 

//login users
router.post('/login', async function (req, res, next) {  
  let loginQuery5=`
  SELECT * FROM project.users 
  WHERE username='${req.body.username}' AND password='${req.body.password}'
  `;
  var result = await pool.query(loginQuery5); 
  if(result.length==0)
  {
      //no user found
      res.json({msg:"no user found"});
  }
  else{

      req.session.user=result[0];
      res.json({msg:"connected"}); 

  } 
});

//logout
router.post('/logout', async function (req, res, next) {  
  let loginQuery6=`
  SELECT * FROM project.users 
  WHERE username='${req.body.username}' AND password='${req.body.password}'
  `;
  var result = await pool.query(loginQuery6); 
  if(result.length==1)
  {
      req.session.user=result[0];
      res.json({msg:"logout"}); 

  } 
});

//show vacation
router.get('/vacations', async (req, res, next) => {
  try {
      let result= await pool.query('SELECT * FROM project.vacation');
      res.json(result);
  } catch (err) {
      res.send(err)
  } 
}); 


//admin- add vacation
router.post('/addvacation', async (req, res, next) => {
  let q=`
  INSERT INTO project.vacation ( description , destination , image ,start ,end ,price  )
  VALUES ( '${req.body.description}', '${req.body.destination}' , '${req.body.image}', '${req.body.start}', '${req.body.end}' , '${req.body.price}' ); 
  `
  try {
    
      let dbresult2= await pool.query(q);  
      res.json(dbresult2);

  } catch (err) {
      res.send(err)
  } 
});

//delete vacation
router.post('/deletevacation', async (req, res, next) => {
  let q2=`
  DELETE FROM project.vacation ( id , destination )
  WHERE  ( ${req.body.id}, '${req.body.destination}' ); 
  `
  try {
    
      let dbresult3= await pool.query(q2);  
      res.json(dbresult3);

  } catch (err) {
      res.send(err)
  } 
});
module.exports = router;
