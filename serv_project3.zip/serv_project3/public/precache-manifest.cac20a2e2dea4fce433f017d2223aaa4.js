self.__precacheManifest = [
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "ba1e92c6a8922638a5e8",
    "url": "/static/js/main.ba1e92c6.chunk.js"
  },
  {
    "revision": "654a694662540c7cc78b",
    "url": "/static/js/2.654a6946.chunk.js"
  },
  {
    "revision": "ba1e92c6a8922638a5e8",
    "url": "/static/css/main.3e802e52.chunk.css"
  },
  {
    "revision": "005169a52ec47f5867ea5c4992f2b0a0",
    "url": "/index.html"
  }
];