self.__precacheManifest = [
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "f53844b6ec48a04616d6",
    "url": "/static/js/main.f53844b6.chunk.js"
  },
  {
    "revision": "654a694662540c7cc78b",
    "url": "/static/js/2.654a6946.chunk.js"
  },
  {
    "revision": "f53844b6ec48a04616d6",
    "url": "/static/css/main.3e802e52.chunk.css"
  },
  {
    "revision": "495d6c02b55b265379ae31a4cb414616",
    "url": "/index.html"
  }
];