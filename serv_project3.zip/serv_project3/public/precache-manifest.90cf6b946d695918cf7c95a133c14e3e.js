self.__precacheManifest = [
  {
    "revision": "fdfcfda2d9b1bf31db52",
    "url": "/static/js/runtime~main.fdfcfda2.js"
  },
  {
    "revision": "0882de9ef59ce8a6bcca",
    "url": "/static/js/main.0882de9e.chunk.js"
  },
  {
    "revision": "654a694662540c7cc78b",
    "url": "/static/js/2.654a6946.chunk.js"
  },
  {
    "revision": "0882de9ef59ce8a6bcca",
    "url": "/static/css/main.83e659ec.chunk.css"
  },
  {
    "revision": "065b9e2b43753d5be6f1712a839c24c7",
    "url": "/index.html"
  }
];